﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KhanhHoaTravel.Models.ViewModels
{
    public class UserViewModel
    {
        public IEnumerable<_User> user { get; set; }
    }
}
